// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"


#include "Procs.h"


BOOL g_IsNt;

//NT
TfnEnumProcesses fnEnumProcesses;
TfnEnumProcessModules fnEnumProcessModules;
TfnGetModuleFileNameExA fnGetModuleFileNameExA;
TfnGetModuleInformation fnGetModuleInformation;

//9X
TfnCreateToolhelp32Snapshot fnCreateToolhelp32Snapshot;
TfnProcess32First fnProcess32First;
TfnProcess32Next fnProcess32Next;
TfnModule32First fnModule32First;
TfnModule32Next fnModule32Next;

HMODULE *g_ModuleList = NULL;
DWORD *g_ProcessList = NULL;

BOOL InitLib_Nt()
{
	HMODULE hLib = LoadLibrary( _T("PSAPI.DLL") );
	if (hLib == NULL) return FALSE;

	fnEnumProcesses = (TfnEnumProcesses)GetProcAddress( hLib, "EnumProcesses" );
	fnEnumProcessModules = (TfnEnumProcessModules)GetProcAddress( hLib, "EnumProcessModules" );
	fnGetModuleFileNameExA = (TfnGetModuleFileNameExA)GetProcAddress( hLib, "GetModuleFileNameExA" );
	fnGetModuleInformation = (TfnGetModuleInformation)GetProcAddress( hLib, "GetModuleInformation" );

	return (fnEnumProcesses) && (fnEnumProcessModules) && (fnGetModuleFileNameExA) && (fnGetModuleInformation);
}

BOOL InitLib_9x()
{
	HMODULE hLib = LoadLibrary( _T("KERNEL32.DLL") );
	if (hLib == NULL) return FALSE;

	fnCreateToolhelp32Snapshot = (TfnCreateToolhelp32Snapshot)GetProcAddress(hLib, "CreateToolhelp32Snapshot");
	fnProcess32First = (TfnProcess32First)GetProcAddress(hLib, "Process32First");
	fnProcess32Next = (TfnProcess32Next)GetProcAddress(hLib, "Process32Next");
	fnModule32First = (TfnModule32First)GetProcAddress(hLib, "Module32First");
	fnModule32Next = (TfnModule32Next)GetProcAddress(hLib, "Module32Next");

	return (fnCreateToolhelp32Snapshot) && (fnProcess32First) && (fnProcess32Next) && (fnModule32First) && (fnModule32Next);

}


//////////////////////////////////////////////////////////////////////////
// BOOL Fix_Module()
// {
// 	//����LoadPE�����̶���С�ĵط�
// 	HMODULE hMod;
// 	//GetModuleHandleList
// 	
// 	
// 	//ProcessList
// 
// }


BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		{
			g_ProcessList = NULL;
			g_ModuleList = NULL;			

			g_IsNt = !(GetVersion() >> 31);
			if ( g_IsNt )
			{
				return InitLib_Nt();
			} 
			else
			{
				return InitLib_9x();
			}			
		}
		break;
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		{
			if (g_ModuleList)
			{
				delete []g_ModuleList;
				g_ModuleList = NULL;
			}
			if (g_ProcessList)
			{
				delete []g_ModuleList;
				g_ProcessList = NULL;
			}

		}
		break;
	}
	return TRUE;
}

