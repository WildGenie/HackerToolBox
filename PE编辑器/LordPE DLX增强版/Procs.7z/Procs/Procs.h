#ifndef _PROCES_H_
#define _PROCES_H_

/*
����ʹ��Asciiģʽ����, LordPE����ֻ֧��Ascii����
*/
#include <Tlhelp32.h>//9x
#include <Psapi.h>//nt


typedef BOOL (WINAPI *TfnEnumProcesses)(
										__out         DWORD* pProcessIds,
										__in          DWORD cb,
										__out         DWORD* pBytesReturned
								  );
typedef BOOL (WINAPI *TfnEnumProcessModules)(
	__in          HANDLE hProcess,
	__out         HMODULE* lphModule,
	__in          DWORD cb,
	__out         LPDWORD lpcbNeeded
	);

typedef DWORD (WINAPI *TfnGetModuleFileNameExA)(
	__in          HANDLE hProcess,
	__in          HMODULE hModule,
	__out         LPTSTR lpFilename,
	__in          DWORD nSize
	);

typedef BOOL (WINAPI *TfnGetModuleInformation)(
	__in          HANDLE hProcess,
	__in          HMODULE hModule,
	__out         LPMODULEINFO lpmodinfo,
	__in          DWORD cb
	);


typedef HANDLE (WINAPI *TfnCreateToolhelp32Snapshot)(   DWORD dwFlags,   DWORD th32ProcessID );
typedef BOOL (WINAPI *TfnProcess32First)(   HANDLE hSnapshot,   LPPROCESSENTRY32 lppe );
typedef BOOL (WINAPI *TfnProcess32Next)(   HANDLE hSnapshot,   LPPROCESSENTRY32 lppe );
typedef BOOL (WINAPI *TfnModule32First)(   HANDLE hSnapshot,   LPMODULEENTRY32 lpme );
typedef BOOL (WINAPI *TfnModule32Next)(   HANDLE hSnapshot,   LPMODULEENTRY32 lpme );

#endif