// Procs.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"

#include "Procs.h"

#include <string.h>
/*
  
GetModuleHandleEx    20002060 1           
GetModuleHandleList  20001A10 2           
GetModulePath        20001BB0 3           
GetModuleSize        20001CE0 4           
GetNumberOfModules   200018F0 5           
GetNumberOfProcesses 20001200 6           
GetProcessBaseSize   200015E0 7           
GetProcessIDList     200012C0 8           
GetProcessPath       20001420 9           
GetProcessPathID     20001E60 10          
*/

//////////////////////////////////////////////////////////////////////////
extern BOOL g_IsNt;
//NT
extern TfnEnumProcesses fnEnumProcesses;
extern TfnEnumProcessModules fnEnumProcessModules;
extern TfnGetModuleFileNameExA fnGetModuleFileNameExA;
extern TfnGetModuleInformation fnGetModuleInformation;
//9x
extern TfnCreateToolhelp32Snapshot fnCreateToolhelp32Snapshot;
extern TfnProcess32First fnProcess32First;
extern TfnProcess32Next fnProcess32Next;
extern TfnModule32First fnModule32First;
extern TfnModule32Next fnModule32Next;



//////////////////////////////////////////////////////////////////////////
DWORD __stdcall GetNumberOfModules(DWORD dwProcessId);
DWORD __stdcall GetNumberOfProcesses();


//////////////////////////////////////////////////////////////////////////
HMODULE __stdcall _GetModuleHandleEx(DWORD dwProcessId, const char *ModuleName)
{
	char ExePath[MAX_PATH];

	lstrcpyA(ExePath, ModuleName);
	_strupr_s(ExePath);

	if (!g_IsNt)
	{
		HANDLE hSnap;
		MODULEENTRY32 me;

		memset(&me, 0, sizeof(me) );
		me.dwSize = sizeof(me);		
		if ( !g_IsNt )
		{
			hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPMODULE , dwProcessId);
			if ( hSnap == INVALID_HANDLE_VALUE ) return 0;

			if ( fnModule32First(hSnap, &me) )
			{
				do 
				{
					_strupr_s(me.szExePath);
					if ( strstr(me.szExePath, ExePath) )
					{
						CloseHandle(hSnap);
						return (HMODULE)me.modBaseAddr;
					}

				} while ( fnModule32Next(hSnap, &me));
			}
			CloseHandle(hSnap);
			return 0;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//NT, PSAPI
	HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, dwProcessId);
	if (!hProcess) return 0;

	HMODULE Base = NULL;	

	//ѭ�����ɹ�Ϊֹ
	HMODULE *Modules = NULL;
	DWORD Size = 0;
	DWORD cbNeed = 0;
	do
	{
		Size += 0x1000;
		Modules = (HMODULE *) new char [Size];
		if ( !Modules ) break;
		if ( !fnEnumProcessModules( hProcess, Modules, Size, &cbNeed ) )
		{
			delete []Modules;
			Modules = NULL;
			break;
		}
	}while (cbNeed >= Size);	

	//////////////////////////////////////////////////////////////////////////
	if (Modules )
	{
		//��ȡ�ɹ�
		DWORD Count = cbNeed / sizeof(HMODULE *);
		char ModuleName[MAX_PATH];
		
		for (DWORD i = 0; i < Count; i++)
		{

			if ( fnGetModuleFileNameExA(hProcess, Modules[i], ModuleName, sizeof(ModuleName) ) )
			{
				_strupr_s(ModuleName);
				if ( strstr(ModuleName, ExePath) )
				{
					Base = Modules[i];					
					break;
				}
			}
		}

		delete[]Modules;		
	}

	CloseHandle(hProcess);
	return Base;
}

BOOL PatchDword(DWORD va, DWORD val)
{
	BOOL Result = FALSE;
	DWORD OldProtect;
	if (VirtualProtect( (LPVOID)va, sizeof(val), PAGE_EXECUTE_READWRITE, &OldProtect))
	{
		memcpy((void *)va, &val, sizeof(val));
		Result = VirtualProtect( (LPVOID)va, sizeof(val), OldProtect, &OldProtect);
	}
	return Result;
}


extern HMODULE *g_ModuleList;
extern DWORD *g_ProcessList;

//////////////////////////////////////////////////////////////////////////
//������û���ض�λ
BOOL Fix_ProcesssList(DWORD **ProcessList, DWORD *Size)
{
	BOOL Result = TRUE;
	DWORD n = GetNumberOfProcesses();
	HMODULE hBase = GetModuleHandle( 0 );
	DWORD *Save = NULL;
	if ((n) && (*Size < n * sizeof(DWORD)) && ((((DWORD)*ProcessList == 0x0041E660) && (*Size == 0xF0))||(*ProcessList == g_ProcessList)))
	{
		Result = FALSE;
		if (*ProcessList == g_ProcessList)
		{
			Save = g_ProcessList;			
		}
		for (;;)
		{
			g_ProcessList = new DWORD[n+10];
			if (g_ProcessList )
			{				
				*ProcessList = g_ProcessList;
				*Size = (n + 10) * sizeof(DWORD);
				memset(g_ProcessList, 0, *Size );
				//
				if(!PatchDword( 0x00405FAC + 1, DWORD(g_ProcessList))) break;;
				if(!PatchDword( 0x00405FA7 + 1, *Size )) break;
				//
				if(!PatchDword( 0x004049F1 + 3, (DWORD)g_ProcessList)) break;
				if(!PatchDword( 0x00404CE3 + 3, (DWORD)g_ProcessList)) break;
				if(!PatchDword( 0x00404E51 + 3, (DWORD)g_ProcessList)) break;
				if(!PatchDword( 0x00404F01 + 3, (DWORD)g_ProcessList)) break;
				if(!PatchDword( 0x00404F2D + 3, (DWORD)g_ProcessList)) break;	
				if(!PatchDword( 0x00404FA3 + 3, (DWORD)g_ProcessList)) break;
				if(!PatchDword( 0x004058B8 + 2, (DWORD)g_ProcessList)) break;
				if(!PatchDword( 0x004059DE + 3, (DWORD)g_ProcessList)) break;
				if(!PatchDword( 0x00405FCC + 1, (DWORD)g_ProcessList)) break;
				if(!PatchDword( 0x004061A5 + 3, (DWORD)g_ProcessList)) break;
				
				Result = TRUE;
			}
			break;
		}
		if (Save)
		{
			delete []Save;
		}
	}

	return Result;
}


BOOL Fix_ModuleList(DWORD dwProcessId, HMODULE **Modules, DWORD *Size)
{
	BOOL Result = TRUE;
	DWORD n = GetNumberOfModules(dwProcessId);
	HMODULE hBase = GetModuleHandle( 0 );
	HMODULE *Save = NULL;
	if ((n) && (*Size < n * sizeof(HMODULE)) && ((((DWORD)*Modules == 0x0041E780) && (*Size == 0x2D0))||(*Modules == g_ModuleList)))
	{
		Result = FALSE;
		if (*Modules == g_ModuleList)
		{
			Save = g_ModuleList;			
		}
		for (;;)
		{
			g_ModuleList = new HMODULE[n+10];
			if (g_ModuleList )
			{
				*Modules = g_ModuleList;
				*Size = (n + 10) * sizeof(HMODULE);
				memset(g_ModuleList, 0, *Size );
				//
				if(!PatchDword( 0x004062B7 + 1, DWORD(g_ModuleList))) break;;
				if(!PatchDword( 0x004062B2 + 1, *Size)) break;
				//
				if(!PatchDword( 0x00405055 + 3, (DWORD)g_ModuleList)) break;
				if(!PatchDword( 0x00405087 + 3, (DWORD)g_ModuleList)) break;
				if(!PatchDword( 0x004050BA + 3, (DWORD)g_ModuleList)) break;
				if(!PatchDword( 0x00405105 + 3, (DWORD)g_ModuleList)) break;
				if(!PatchDword( 0x004062DB + 1, (DWORD)g_ModuleList)) break;	
				Result = TRUE;
			}
			break;
		}
		if (Save)
		{
			delete []Save;
		}
	}

	return Result;
}



//////////////////////////////////////////////////////////////////////////

BOOL __stdcall GetModuleHandleList(DWORD dwProcessId, HMODULE *Modules, DWORD Size)
{
	BOOL Result = FALSE;

	if (!Fix_ModuleList(dwProcessId, &Modules, &Size)) return FALSE;

	//Nt
	if ( g_IsNt )
	{
		HANDLE hProcess = OpenProcess( PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, dwProcessId);
		
		if (hProcess)
		{
			DWORD cbNeed = 0;
			Result = fnEnumProcessModules(hProcess, Modules, Size, &cbNeed);
			CloseHandle(hProcess);
		}		
		return Result;
	}

	//9x
	//while Size 
	HANDLE hSnap;
	MODULEENTRY32 me;

	memset(&me, 0, sizeof(me) );
	me.dwSize = sizeof(me);		
	
	hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPMODULE , dwProcessId);
	if ( hSnap == INVALID_HANDLE_VALUE ) return FALSE;

	if ( fnModule32First(hSnap, &me) )
	{
		Result = TRUE;
		DWORD i = 0;
		do 
		{
			if (Size < sizeof(HMODULE *))
			{
				OutputDebugString("Overflow");
				break;//���ܻ����Խ��
			}
			Modules[i++] = (HMODULE)me.modBaseAddr;
			Size -= sizeof(HMODULE *);

		} while ( fnModule32Next(hSnap, &me));
	}
	CloseHandle(hSnap);

	return Result;
}

BOOL __stdcall GetModulePath(DWORD dwProcessId, HMODULE hModule, LPSTR ModulePath, DWORD ModuleSize)
{
	BOOL Result = FALSE;
	//Nt
	if ( g_IsNt )
	{
		HANDLE hProcess = OpenProcess( PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, dwProcessId);
		if (hProcess)
		{
			Result = fnGetModuleFileNameExA(hProcess, hModule, ModulePath, ModuleSize);
			CloseHandle(hProcess);
		}		
		return Result;
	}

	//9x
	HANDLE hSnap;
	MODULEENTRY32 me;

	memset(&me, 0, sizeof(me) );
	me.dwSize = sizeof(me);		
	hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPMODULE , dwProcessId);
	if ( hSnap != INVALID_HANDLE_VALUE )
	{
		if ( fnModule32First(hSnap, &me) )
		{
			do 
			{
				if ((HMODULE)me.modBaseAddr == hModule)
				{
					Result = TRUE;
					DWORD nLength = strlen(me.szExePath);
					if (nLength  >  ModuleSize ) nLength = ModuleSize;
					lstrcpynA(ModulePath, me.szExePath, nLength );
					break;						
				}
			} while ( fnModule32Next(hSnap, &me));
		}
		CloseHandle(hSnap);
	}
	
	return Result;
}



BOOL __stdcall GetModuleSize(DWORD dwProcessId, HMODULE hModule, DWORD *ModuleSize)
{
	BOOL Result = FALSE;
	//Nt
	if ( g_IsNt )
	{
		HANDLE hProcess = OpenProcess( PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, dwProcessId);
		if (hProcess)
		{
			MODULEINFO mi;
			Result = fnGetModuleInformation(hProcess, hModule, &mi, sizeof(mi));
			*ModuleSize = mi.SizeOfImage;
			CloseHandle(hProcess);
		}		
		return Result;
	}

	//9x
	HANDLE hSnap;
	MODULEENTRY32 me;

	memset(&me, 0, sizeof(me) );
	me.dwSize = sizeof(me);		
	hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPMODULE , dwProcessId);
	if ( hSnap != INVALID_HANDLE_VALUE )
	{

		if ( fnModule32First(hSnap, &me) )
		{
			do 
			{
				if ((HMODULE)me.modBaseAddr == hModule)
				{
					Result = TRUE;
					*ModuleSize = me.modBaseSize;
					break;						
				}
			} while ( fnModule32Next(hSnap, &me));
		}
		CloseHandle(hSnap);
	}

	return Result;
}

DWORD __stdcall GetNumberOfModules(DWORD dwProcessId)
{
	DWORD Result = 0;
	//Nt
	if ( g_IsNt )
	{
		HANDLE hProcess = OpenProcess( PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, dwProcessId);
		if (hProcess)
		{
			HMODULE *Modules = NULL;
			DWORD Size = 0;
			DWORD cbNeed = 0;
			do
			{
				Size += 0x1000;
				Modules = (HMODULE *) new char [Size];
				if ( !Modules ) break;
				if ( !fnEnumProcessModules( hProcess, Modules, Size, &cbNeed ) )
				{
					delete []Modules;
					Modules = NULL;
					break;
				}
			}while (cbNeed >= Size);
			if (Modules)
			{
				Result = cbNeed / sizeof(HMODULE);
				delete[]Modules;
			}		

			CloseHandle(hProcess);
		}		
		return Result;
	}

	//9x
	HANDLE hSnap;
	MODULEENTRY32 me;

	memset(&me, 0, sizeof(me) );
	me.dwSize = sizeof(me);		
	hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPMODULE , dwProcessId);
	if ( hSnap != INVALID_HANDLE_VALUE )
	{
		if ( fnModule32First(hSnap, &me) )
		{
			do 
			{
				Result++;
			} while ( fnModule32Next(hSnap, &me));
		}
		CloseHandle(hSnap);
	}

	return Result;

}

DWORD __stdcall GetNumberOfProcesses()
{
	DWORD Result = 0;
	//Nt
	if ( g_IsNt )
	{
		//cbNeed���ص���ʵ�ʴ�С!
		DWORD *ProcessIds = NULL;
		DWORD Size = 0;
		DWORD cbNeed = 0;
		do
		{
			Size += 0x1000;
			ProcessIds = (DWORD *) new char [Size];
			if (!ProcessIds) break;
			if ( !fnEnumProcesses( ProcessIds, Size, &cbNeed ) )
			{
				delete []ProcessIds;
				ProcessIds = NULL;
				break;
			}
		}while (cbNeed >= Size);
		if (ProcessIds)
		{
			Result = cbNeed / sizeof(DWORD);
			delete[]ProcessIds;
		}
		return Result;
	}			
	

	//9x
	HANDLE hSnap;
	PROCESSENTRY32 pe;

	memset( &pe, 0, sizeof(pe) );
	pe.dwSize = sizeof(pe);		
	hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0);
	if ( hSnap != INVALID_HANDLE_VALUE )
	{
		if ( fnProcess32First(hSnap, &pe) )
		{
			do 
			{
				Result++;
			} while ( fnProcess32Next(hSnap, &pe));
		}
		CloseHandle(hSnap);
	}

	return Result;
}


BOOL __stdcall GetProcessBaseSize(DWORD dwProcessId, DWORD *ProcessBase , DWORD *ProcessSize )
{
	BOOL Result = FALSE;
	if (g_IsNt)
	{
		HANDLE hProcess = OpenProcess( PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, dwProcessId);

		if (hProcess)
		{
			HMODULE Module = NULL;
			DWORD cbNeed = 0;
			if (fnEnumProcessModules(hProcess, &Module, sizeof(Module), &cbNeed))
			{
				MODULEINFO mi;
				if ( fnGetModuleInformation(hProcess, Module, &mi, sizeof(mi)) )
				{
					Result = TRUE;
					*ProcessBase = (DWORD)mi.lpBaseOfDll;
					*ProcessSize = mi.SizeOfImage;
				}

			}
			CloseHandle(hProcess);
		}		
		return Result;
	}

	//9x
	char ExePath[MAX_PATH];
	memset( ExePath, 0, sizeof(ExePath) );
	{
		//�õ�������
		HANDLE hSnap;
		PROCESSENTRY32 pe;

		memset( &pe, 0, sizeof(pe) );
		pe.dwSize = sizeof(pe);		
		hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0);
		if ( hSnap != INVALID_HANDLE_VALUE )
		{
			if ( fnProcess32First(hSnap, &pe) )
			{
				do 
				{
					if (pe.th32ProcessID == dwProcessId)
					{
						
						DWORD nLength = strlen(pe.szExeFile);
						if (nLength  >  sizeof(ExePath) ) nLength = sizeof(ExePath);
						lstrcpynA(ExePath, pe.szExeFile, nLength );

						break;
					}
				} while ( fnProcess32Next(hSnap, &pe));
			}
			CloseHandle(hSnap);
		}

	}

	HANDLE hSnap;
	MODULEENTRY32 me;

	memset(&me, 0, sizeof(me) );
	me.dwSize = sizeof(me);		
	hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPMODULE , dwProcessId);
	if ( hSnap != INVALID_HANDLE_VALUE )
	{
		if ( fnModule32First(hSnap, &me) )
		{
			do 
			{
				if ( !lstrcmpiA(me.szExePath, &ExePath[0]) )
				{
					Result = TRUE;
					*ProcessBase = (DWORD)me.modBaseAddr;
					*ProcessSize = me.modBaseSize;
					break;				
				}
				;
			} while ( fnModule32Next(hSnap, &me));
		}
		CloseHandle(hSnap);
	}



	return Result;
}

BOOL __stdcall GetProcessIDList(DWORD *pProcessIds, DWORD cb)
{
	BOOL Result = FALSE;

	if (!Fix_ProcesssList( &pProcessIds, &cb)) return FALSE;	
	
	//Nt
	if ( g_IsNt )
	{
		DWORD cbNeed = 0;
		Result = fnEnumProcesses( pProcessIds, cb, &cbNeed ) ;//����û�п��Ǵ�С����
		return Result;
	}

	//9x
	HANDLE hSnap;
	PROCESSENTRY32 pe;

	memset( &pe, 0, sizeof(pe) );
	pe.dwSize = sizeof(pe);		
	hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0);
	if ( hSnap != INVALID_HANDLE_VALUE )
	{
		DWORD i = 0;
		if ( fnProcess32First(hSnap, &pe) )
		{
			Result = TRUE;
			do 
			{
				if (cb < sizeof(DWORD))
				{
					OutputDebugString("Overflow");
					break;//���ܻ����Խ��
				}
				pProcessIds[i++] = pe.th32ProcessID;
				cb -= sizeof(DWORD);
			} while ( fnProcess32Next(hSnap, &pe));
		}
		CloseHandle(hSnap);
	}

	return Result;
}

BOOL __stdcall GetProcessPath(DWORD dwProcessId, LPSTR ModulePath, DWORD ModuleSize)
{
	BOOL Result = FALSE;
	if ( g_IsNt )
	{
		HANDLE hProcess = OpenProcess(0x410u, 0, dwProcessId);
		if ( hProcess )
		{
			HMODULE Module = NULL;
			DWORD cbNeed = 0;
			if ( fnEnumProcessModules(hProcess, &Module, sizeof(Module), &cbNeed) )
			{
				Result = (fnGetModuleFileNameExA(hProcess, Module, ModulePath, ModuleSize) != 0);
			}
			CloseHandle(hProcess);			
		}
		return Result;
	}
	//9x
	HANDLE hSnap;
	PROCESSENTRY32 pe;

	memset( &pe, 0, sizeof(pe) );
	pe.dwSize = sizeof(pe);		
	hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0);
	if ( hSnap != INVALID_HANDLE_VALUE )
	{
		DWORD i = 0;
		if ( fnProcess32First(hSnap, &pe) )
		{			
			do 
			{
				if (pe.th32ProcessID == dwProcessId)
				{
					Result = TRUE;
					DWORD nLength = strlen(pe.szExeFile);
					if (nLength  >  ModuleSize ) nLength = ModuleSize;
					lstrcpynA(ModulePath, pe.szExeFile, nLength );

					break;
				}				
			} while ( fnProcess32Next(hSnap, &pe));
		}
		CloseHandle(hSnap);
	}

	return Result;

}


//FindProcessByProcessName
DWORD __stdcall GetProcessPathID(LPCSTR ProcessName)
{
	DWORD Result = 0;
	char szProcessName[MAX_PATH];

	strcpy_s(szProcessName, ProcessName );
	_strupr_s( szProcessName );
	//Nt
	if (g_IsNt)
	{
		//����ö�ٳ����Ľ���, ��������		
		DWORD *ProcessIds = NULL;
		DWORD Size = 0;
		DWORD cbNeed = 0;
		do
		{
			Size += 0x1000;
			ProcessIds = (DWORD *) new char [Size];
			if (!ProcessIds) break;
			if ( !fnEnumProcesses( ProcessIds, Size, &cbNeed ) )
			{
				delete []ProcessIds;
				ProcessIds = NULL;
				break;
			}
		}while (cbNeed >= Size);

		//////////////////////////////////////////////////////////////////////////
		if (ProcessIds )
		{
			//��ȡ�ɹ�
			DWORD Count = cbNeed / sizeof(DWORD);
			for (DWORD i = 0; i < Count; i++)
			{
				HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, ProcessIds[i]);
				if (hProcess)
				{
					HMODULE Modules = 0;
					DWORD cbNeed = 0;
					if (fnEnumProcessModules( hProcess, &Modules, sizeof(Modules), &cbNeed))
					{
						if ( fnGetModuleFileNameExA(hProcess, Modules, szProcessName, sizeof(szProcessName) ) )
						{
							_strupr_s(szProcessName);
							if ( strstr(szProcessName, ProcessName) )
							{
								Result = ProcessIds[i];
								break;
							}
						}
						
					}
					CloseHandle( hProcess );
				}
			}

			delete[]ProcessIds;		
		}

		return Result;
	}

	//9x
	HANDLE hSnap;
	PROCESSENTRY32 pe;

	memset( &pe, 0, sizeof(pe) );
	pe.dwSize = sizeof(pe);		
	hSnap = fnCreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0);
	if ( hSnap != INVALID_HANDLE_VALUE )
	{
		DWORD i = 0;
		if ( fnProcess32First(hSnap, &pe) )
		{			
			do 
			{
				_strupr_s(pe.szExeFile);
				if ( strstr(pe.szExeFile, &szProcessName[0]) )
				{
					Result = pe.th32ProcessID;
					break;
				}				
			} while ( fnProcess32Next(hSnap, &pe));
		}
		CloseHandle(hSnap);
	}


	return Result;
}